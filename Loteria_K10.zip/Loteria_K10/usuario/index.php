<?php
session_start();
if(isset($_SESSION["user"])){
$id = $_SESSION["car"];
$us = $_SESSION["user"];
}else
 header("location: ../");
{

}
?>


<!DOCTYPE html>
<html>
<head>
	<title>lote</title>
	<link rel="stylesheet" type="text/css" href="../css/mostrar.css">
</head>
<body>
<center><h1>Bienvenido</h1></center>

<center>
<?php

require "../conn/conexion.php";

$sql = "SELECT Id, c1, c2,c3, c4, c5, c6, c7, c8, c9, estado FROM carton where Id='$id'";

$result = $conexion->query($sql);


if($result->num_rows > 0){

	while ($row = $result->fetch_assoc()) {
			
		if ($row["estado"] == 1) {
				echo "<table border='1' class='reser'>";
		}else{
			echo "<table border='1'>";
		}

			?>
			<tr>
				<th colspan="3"><?php echo "carton: ".$row["Id"]; ?></th>
			</tr>
			<tr>
				<td><a href="#" onclick="filtro(1);" id="f1"><img src="../media/img/<?php echo $row['c1'].'.jpg'; ?>"></td>
				<td><a href="#" onclick="filtro(2);" id="f2"><img src="../media/img/<?php echo $row['c2'].'.jpg'; ?>"></td>
				<td><a href="#" onclick="filtro(3);" id="f3"><img src="../media/img/<?php echo $row['c3'].'.jpg'; ?>"></td>
			</tr>
			<tr>
				<td><a href="#" onclick="filtro(4);" id="f4"><img src="../media/img/<?php echo $row['c4'].'.jpg'; ?>"></td>
				<td><a href="#" onclick="filtro(5);" id="f5"><img src="../media/img/<?php echo $row['c5'].'.jpg'; ?>"></td>
				<td><a href="#" onclick="filtro(6);" id="f6"><img src="../media/img/<?php echo $row['c6'].'.jpg'; ?>"></td>
			</tr>
			<tr>
				<td><a href="#" onclick="filtro(7);" id="f7"><img src="../media/img/<?php echo $row['c7'].'.jpg'; ?>"></td>
				<td><a href="#" onclick="filtro(8);" id="f8"><img src="../media/img/<?php echo $row['c8'].'.jpg'; ?>"></td>
				<td><a href="#" onclick="filtro(9);" id="f9"><img src="../media/img/<?php echo $row['c9'].'.jpg'; ?>"></td>
			</tr>
			
			<?php
			echo "</table>";
	}

}

?>






</center>
<br>
<center><a href="salir.php"><button>LISTO</button></a></center>

<script type="text/javascript">
var btn1 = {num: 1,estado: 0};
var btn2 = {num: 2,estado: 0};
var btn3 = {num: 3,estado: 0};
var btn4 = {num: 4,estado: 0};
var btn5 = {num: 5,estado: 0};
var btn6 = {num: 6,estado: 0};
var btn7 = {num: 7,estado: 0};
var btn8 = {num: 8,estado: 0};
var btn9 = {num: 9,estado: 0};

function filtro(x){

if(x == btn1.num){
	if (btn1.estado == 0) {
		document.getElementById('f1').style.filter = "brightness(20%)";
		btn1.estado = 1;
	}else{
		document.getElementById('f1').style.filter = "brightness(100%)";
		btn1.estado = 0;
	}

}else if(x == btn2.num){
	if (btn2.estado == 0) {
		document.getElementById('f2').style.filter = "brightness(20%)";
		btn2.estado = 1;
	}else{
		document.getElementById('f2').style.filter = "brightness(100%)";
		btn2.estado = 0;
	}

}else if(x == btn3.num){
	if (btn3.estado == 0) {
		document.getElementById('f3').style.filter = "brightness(20%)";
		btn3.estado = 1;
	}else{
		document.getElementById('f3').style.filter = "brightness(100%)";
		btn3.estado = 0;
	}

}else if(x == btn4.num){
	if (btn4.estado == 0) {
		document.getElementById('f4').style.filter = "brightness(20%)";
		btn4.estado = 1;
	}else{
		document.getElementById('f4').style.filter = "brightness(100%)";
		btn4.estado = 0;
	}

}else if(x == btn5.num){
	if (btn5.estado == 0) {
		document.getElementById('f5').style.filter = "brightness(20%)";
		btn5.estado = 1;
	}else{
		document.getElementById('f5').style.filter = "brightness(100%)";
		btn5.estado = 0;
	}

}else if(x == btn6.num){
	if (btn6.estado == 0) {
		document.getElementById('f6').style.filter = "brightness(20%)";
		btn6.estado = 1;
	}else{
		document.getElementById('f6').style.filter = "brightness(100%)";
		btn6.estado = 0;
	}

}else if(x == btn7.num){
	if (btn7.estado == 0) {
		document.getElementById('f7').style.filter = "brightness(20%)";
		btn7.estado = 1;
	}else{
		document.getElementById('f7').style.filter = "brightness(100%)";
		btn7.estado = 0;
	}

}else if(x == btn8.num){
	if (btn8.estado == 0) {
		document.getElementById('f8').style.filter = "brightness(20%)";
		btn8.estado = 1;
	}else{
		document.getElementById('f8').style.filter = "brightness(100%)";
		btn8.estado = 0;
	}

} if(x == btn9.num){
	if (btn9.estado == 0) {
		document.getElementById('f9').style.filter = "brightness(20%)";
		btn9.estado = 1;
	}else{
		document.getElementById('f9').style.filter = "brightness(100%)";
		btn9.estado = 0;
	}

}

}

</script>
</body>
</html>