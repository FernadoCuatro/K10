<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta refresh="1">
</head>
<body>



<?php

require "../conn/conexion.php";
if(isset($_POST["bt"])){
$nm = $_POST["nm"];
$ap = $_POST["ap"];
$cr =  mt_rand(1,15);

$sql1 = "SELECT * FROM carton WHERE Id='$cr' and estado='0'";

$sql = "SELECT * FROM carton WHERE  estado='0'";



$re = $conexion->query($sql);
if($re->num_rows > 0){


$res = $conexion->query($sql1);
if($res->num_rows == 1){
		$_SESSION["car"] = $cr;


$sql2 = "INSERT INTO jugador(nombre, apellido, carton) VALUES ('$nm','$ap','$cr');";
$sql3 = "SELECT @@identity AS Cod";
$sql4 = "UPDATE carton SET estado='1' WHERE Id='$cr'";

	if($conexion->query($sql2)){
				$result = $conexion->query($sql3);
		if($result->num_rows == 1){

			while($row=$result->fetch_assoc()){
				$_SESSION["user"] =  $row["Cod"];
			}

				$conexion->query($sql4);
			if(($conexion->affected_rows)==0){
				echo "No se puede actualizar el registro, intente de nuevo.";
    
			}else{
				header("location: index.php");
			
			}

		}
	}else{

	}

}else{
	header("location: ../");
}

}else{
	$cr = mt_rand(1,15);

}

}



?>

</body>
</html>