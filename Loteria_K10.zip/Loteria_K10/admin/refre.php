<?php
		require "../conn/conexion.php";
		$sql="UPDATE carton SET estado='0' WHERE 1;";
		$conexion->query($sql);
		if(($conexion->affected_rows)==0){
			//echo "Nose modifico";
			//echo $conexion->connect_error;
			header("location: index.php");
		}else{
			header("location: index.php");
		}




?>