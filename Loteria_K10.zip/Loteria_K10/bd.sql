drop database IF EXISTS loteria;
create database loteria;
use loteria;
create table carton(
Id INT primary key AUTO_INCREMENT,
c1 int,
c2 int,
c3 int,
c4 int,
c5 int,
c6 int,
c7 int,
c8 int,
c9 int,
estado int default 0
);

create table jugador(
Id int PRIMARY key AUTO_INCREMENT,
nombre varchar(100),
apellido varchar(100),
carton int
);


INSERT INTO `carton` (`Id`, `c1`, `c2`, `c3`, `c4`, `c5`, `c6`, `c7`, `c8`, `c9`, `estado`) VALUES
(1, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0),
(2, 29, 30, 1, 2, 3, 6, 8, 9, 15, 0),
(3, 14, 12, 13, 24, 15, 30, 22, 28, 16, 1),
(4, 2, 4, 6, 8, 10, 12, 14, 16, 18, 1),
(5, 15, 10, 8, 7, 11, 4, 19, 9, 6, 0),
(6, 5, 10, 15, 20, 25, 30, 12, 11, 10, 0),
(7, 15, 18, 1, 14, 12, 6, 21, 11, 30, 0),
(8, 12, 22, 24, 26, 11, 15, 25, 1, 2, 0),
(9, 12, 22, 24, 26, 11, 15, 25, 1, 3, 1),
(10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 0),
(11, 20, 21, 22, 23, 24, 25, 26, 27, 28, 0),
(12, 29, 30, 1, 12, 11, 15, 19, 14, 22, 1),
(13, 11, 7, 17, 1, 2, 3, 5, 12, 11, 0),
(14, 19, 12, 14, 16, 8, 9, 13, 3, 2, 0),
(15, 3, 2, 4, 11, 18, 28, 8, 25, 26, 0);
