
var impri = ' ';
var contador = 1;


function carta(){
	var req = new XMLHttpRequest();
	var ivn = contador;
	req.onreadystatechange = function(){

		if(req.readyState == 4 && req.status == 200){

					//document.getElementById('carta').innerHTML = req.responseText;
					impri += req.responseText;

					document.getElementById('carta').innerHTML = impri;
		}
	}
	//alert(ivn);
	req.open('GET','carta.php?card='+ivn,true);
    req.send();
    contador ++;
}

/*function estilo(){
	alert(contador);
	return contador;


}*/