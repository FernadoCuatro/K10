<?php
session_start();
if(isset($_SESSION["user"])){
header("location: usuario/index.php");
}else
 
{

}
?>

<!DOCTYPE html>
<html>
<head>
	<title>loteria</title>
	<link rel="stylesheet" type="text/css" href="css/inicio.css">
</head>
<body>
<CENTER>
<h1>Bienvenido a la gran loteria</h1>

<form method="post" action="usuario/validar.php" ><br><br><br><br>
<input type="text" name="nm" placeholder="Nombre"  required><br>
<br>
<input type="text" name="ap" placeholder="Apellido" required><br><br>
<input type="submit" name="bt" value="Enviar" id="boton">
</form>
</CENTER>
</body>
</html>