<?php
session_start ();
error_reporting(0);
$usersesion = $_SESSION['usuario'];
if  ($usersesion == null || $usersesion ='' ){
echo 'usted no puede ingresar, por favor registrese';
die(); }?>
<!DOCTYPE html>
<html>
<head><meta charset="utf-8">
<title>Nosotros | K10</title>
<link rel="icon" type="icon" href="material/k101.png">
<link rel="stylesheet" href="css/font.css">
<link rel="stylesheet" href="css/acercade.css">
<link rel="stylesheet" href="css/fuentes.css">
<link rel="stylesheet" href="iconos/iconos.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script></head><header><nav class="menu">
<div class="enlaces" id="enlaces"> <a href="bienvenidos.php">Bienvenido <span class="icon-home"></span></a>
<a href="instrucciones.php">Instrucciones <span class="icon-menu"></span></a></div><div class="logo">
<a href="pago.php"><img src="material/K10C2.png" alt="k10"></div></a><div class="enlaces" id="enlaces">
<a href="acercade.php"><u>Acerca de k10 <span class="icon-slideshare"></span></u></a><a href="xsession.php">cerrar sesión <span class="icon-block"></span></a></div></nav>
</header><body><div class="net"><a href="https://mail.google.com/mail/u/0/#inbox" class="icon icon-google" target="_blank"></a><a href="https://www.facebook.com/fernandocuatrorivera" class="icon icon-facebook2" target="_blank"></a>
<a href="https://www.instagram.com/fernandocuatro.jpg/" class="icon icon-instagram" target="_blank"></a><a href="tel:+50364229837" class="icon icon-whatsapp" target="_blank"></a>
<a href="https://twitter.com/FernandoCuatro" class="icon icon-twitter" target="_blank"></a></div><div class="Papel">
<article><hr><h1>¿Quienes desarrollamos K10?</h1><hr><center><table class="orden"><tr><td><img src="material/foto1.jpg">
<u><br>Fernando Miguel Cuatro Rivera<br></u>Redes sociales:<br><a href="https://www.facebook.com/fernandocuatrorivera" target="_blank" title="Fernando"><span class="demas icon-facebook2"></span></a>
<a href="https://twitter.com/FernandoCuatro" target="_blank" title="@FernandoCuatro"><span class="demas icon-twitter"></span></a>
<a href="https://www.instagram.com/fernandocuatro.jpg/?hl=es-la" target="_blank" title="Fernandocuatro.jpg"><span class="demas icon-instagram"></span></a>
<a href="tel:+50364229837" target="_blank"><span class="demas icon-whatsapp"></span></a></td>	<td><img src="material/foto5.jpg" <br>
<u><br>Carlos Ariel Martinez Duarte<br></u>Redes sociales:<br><a target="_blank" title="No tiene"><span class="demas icon-facebook2"></span></a>
<a target="_blank" title="No tiene"><span class="demas icon-twitter"></span></a><a href="https://www.instagram.com/carlos_martynez/" target="_blank" title="Carlos_martynez"><span class="demas icon-instagram"></span></a>
<a href="tel:+50372560328" target="_blank"><span class="demas icon-whatsapp"></span></a></td></tr>		<tr><td><img src="material/foto2.jpg" <br>
<u><br>Jonathan Alexander Alvarado Granillo<br></u>Redes sociales:<br><a href="https://www.facebook.com/jonathanalvarenga.vasquez" target="_blank" title="Jonathan Alvarado Vazquez"><span class="demas icon-facebook2"></span></a><a target="_blank" title="No tiene"><span class="demas icon-twitter"></span></a>
<a target="_blank" title="No tiene"><span class="demas icon-instagram"></span></a><a href="tel:+50374191765" target="_blank"><span class="demas icon-whatsapp"></span></a></td>	
<td><img src="material/foto3.jpg"<br><u><br>Rudy Alberto Garcia Ramos<br></u>Redes sociales:<br>
<a href="https://www.facebook.com/Rudygarcia2000" target="_blank"  title="Rudy Garcia"><span class="demas icon-facebook2"></span></a>
<a target="_blank"  title="No tiene"><span class="demas icon-twitter"></span></a><a target="_blank"  title="No tiene"><span class="demas icon-instagram"></span></a><a href="tel:+50374923909" target="_blank" ><span class="demas icon-whatsapp"></span></a>
</td></tr><tr><td><img src="material/foto4.jpg" <br><u><br>Xavier Ulises Rojas Moran<br></u>Redes sociales:<br><a href="https://www.facebook.com/ulises.rojas.399" target="_blank" title="Xavier Rojas"><span class="demas icon-facebook2"></span></a><a target="_blank" title="No tiene"><span class="demas icon-twitter"></span></a>
<a href="https://www.instagram.com/xavier_ulises/" target="_blank" title="Xavier_Ulises"><span class="demas icon-instagram"></span></a><a href="tel:+50372374796" target="_blank" ><span class="demas icon-whatsapp"></span></a></td>	<td><img src="material/foto6.jpg" <br>
<u><br>Oswaldo Francisco Barahona Ramirez<br></u>Redes sociales:<br><a href="https://www.facebook.com/fran.barahona.75" target="_blank" title="Barahona"><span class="demas icon-facebook2"></span></a>
<a title="No tiene"><span class="demas icon-twitter"></span></a><a href="https://www.instagram.com/21_bara/" target="_blank" title="21_bara"><span class="demas icon-instagram"></span></a><a href="tel:+50373448760" target="_blank"><span class="demas icon-whatsapp"></span></a>
</td></tr></table></center><p>
<div class="fin">
<h4> ¿Adonde quieres ir? </h4><p><a href="bienvenidos.php"><button class="primero">Bienvenidos <span class="icon-home" id="iconnos"></span></button></a>
<a href="instrucciones.php"><button class="primero">Instrucciones <span class="icon-menu" id="iconnos"></span></button></a></div></article></div>  

<footer>
<section id="acerca de"><h1><img src="material/k107.png"  width="201px" alt="k10"></h1>
<section id class="Final">
Copyright © Corporacion
</id></footer>
</body>
</html>