<?php
$server="localhost";
$user="root";
$password="";
$database="loteria";


$conexion= new mysqli($server, $user, $password, $database);


if ($conexion->connect_error){
	die("error de conexion: ". $conexion->connect_error);
}else{
	
}




?>