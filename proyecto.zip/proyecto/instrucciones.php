<?php
session_start ();
error_reporting(0);
$usersesion = $_SESSION['usuario'];
if  ($usersesion == null || $usersesion ='' ){
echo 'usted no puede ingresar, por favor registrese';
die(); }?>
<!DOCTYPE html>
<html>
<head><meta charset="utf-8">
<title>Reglas | K10</title>
<link rel="icon" type="icon" href="material/k101.png">
<link rel="stylesheet" href="css/font.css">
<link rel="stylesheet" href="css/instrucciones.css">
<link rel="stylesheet" href="css/fuentes.css">
<link rel="stylesheet" href="iconos/iconos.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script></head><header><nav class="menu">
<div class="enlaces" id="enlaces"> <a href="bienvenidos.php">Bienvenido <span class="icon-pin"></span></a>
<a href="instrucciones.php"><u>Instrucciones <span class="icon-new"></u></span></a></div><div class="logo">
<a href="pago.php"><img src="material/K10C2.png" alt="k10"></div></a><div class="enlaces" id="enlaces">
<a href="acercade.php">Acerca de k10 <span class="icon-reply-all"></span></a><a href="xsession.php">cerrar sesión <span class="icon-switch"></span></a></div></nav>
</header><body>
<div class="net"><a href="https://mail.google.com/mail/u/0/#inbox" class="icon icon-google" target="_blank"></a><a href="https://www.facebook.com/fernandocuatrorivera" class="icon icon-facebook2" target="_blank"></a>
<a href="https://www.instagram.com/fernandocuatro.jpg/" class="icon icon-instagram" target="_blank"></a><a href="tel:+50364229837" class="icon icon-whatsapp" target="_blank"></a>
<a href="https://twitter.com/FernandoCuatro" class="icon icon-twitter" target="_blank"></a></div><div class="Papel">


<article><hr><h1>Reglas de K10 <span class="icon-pin"></span></h1><br><hr><p><h2>--<br><span class="icon-game-controller"></span>|k uno|<span class="icon-game-controller"></span><br>--</span></h2><center> El máximo de jugadores será de 15 y el minimo sera 2.<p><hr><p><h3>--<br><span class="icon-game-controller"></span>|k dos|<span class="icon-game-controller"></span><br>--</h3>A cada jugador se le asignara un tablero entre 15 diferentes.<p><hr><p><h2>--<br><span class="icon-game-controller"></span>|k tres|<span class="icon-game-controller"></span><br>--</h2>Se utiliza el clic para seleccionar la imagen que coincida con la exclamada por el gritón.<p><hr><p><h3>--<br><span class="icon-game-controller"></span>|k cuatro|<span class="icon-game-controller"></span><br>--</h3>El administrador k10 da comienzo al juego mencionando las cartas que irán apareciendo al azar y este monitorea los tableros que están en juego.<p><hr><p><h2>--<br><span class="icon-game-controller"></span>|k cinco|<span class="icon-game-controller"></span><br>--</h2>La <big>loteria k10</big> escoge cartas al azar, y grita el nombre en alto.<p><hr><p><h3>--<br><span class="icon-game-controller"></span>|k seis|<span class="icon-game-controller"></span><br>--</h3>Si la imagen de la carta está en la tabla del jugador, este debe seleccionarla para que sea sombreada.<p><hr><p><h2>--<br><span class="icon-game-controller"></span>|k siete|<span class="icon-game-controller"></span><br>--</h2>Si es seleccionada una imagen que no coincida con la exclamación del <big>programa k10</big>, no será válido ya que este tiene el control de cada carta que aparezcan en los cartones.<p><hr><p><h3>--<br><span class="icon-game-controller"></span>|k ocho|<span class="icon-game-controller"></span><br>--</h3>Una carta que esta repetida en distintos tableros es válido, todos tienen derecho a seleccionarla. <p><hr><p><h2>--<br><span class="icon-game-controller"></span>|k nueve|<span class="icon-game-controller"></span><br>--</h2>Una carta no podrá estar repetida en el mismo tablero.<p><hr><p><h3>--<br><span class="icon-game-controller"></span>|k diez|<span class="icon-game-controller"></span><br>--</h3>Gana quien complete en su tabla todas las cartas y grite "¡lotería!".</center><p><hr><p><h2>--<br><span class="icon-game-controller"></span></h2><h1>|Juega ahora aqui|</h1><h2><span class="icon-game-controller"></span><br>--</h2><center><div class="juega"><a href="pago.php"><img src="material/K101.png" alt="k10"></div></center></center><p><hr><p>


<div class="fin">
<h4> ¿Adonde quieres ir? </h4><p><a href="bienvenidos.php"><button class="primero">Bienvenido <span class="icon-pin" id="iconnos"></span></button></a>
<a href="acercade.php"><button class="primero">Acerca de <span class="icon-reply-all" id="iconnos"></span></button></a></div></article></div>  

<footer>
<section id="acerca de"><h1><img src="material/k106.png"  width="201px" alt="k10"></h1>
<section id class="Final">
Copyright © Corporacion
</id></footer>
</body>
</html>