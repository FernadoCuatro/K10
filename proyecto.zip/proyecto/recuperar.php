<?php
error_reporting(0);  
$recuperacion = $_POST ['Correo_busqueda'];

$conexion = mysqli_connect("localhost", "root", "", "loteria");
$consulta = "SELECT * FROM registro WHERE correo='$recuperacion' ";
$resultadodeconsulta =  mysqli_query ($conexion, $consulta);
$filas = mysqli_num_rows ($resultadodeconsulta);
if ($filas>0) 
{
$filas = $resultadodeconsulta -> fetch_assoc();
$_SESSION ['correo'] = $filas ['correo'];
$final ="Tu contraseña es: " .$filas  ["Clave"];
$mostrar = "Tu direccion de correo es: $recuperacion y $final";
}
else {
$nomostrar = "no se encuntran coicidencias con ese correo electronico.";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="icon" type="icon" href="material/k101.png">
<link rel="stylesheet" type="text/css" href="css/recuperar2.css">
<title>Recuperar | K10</title>
</head>
<body>
<div class="cuadro">
<p><?php echo $mostrar; ?>
<p><?php echo $nomostrar; ?>
</div>
<div class="final">
<a href="recuperar.html"><input type="button" value="volver a recuperar"></a>
<a href="index.html"><input type="button" value="volver al log in"></a>
	</div>
</body>
</html>