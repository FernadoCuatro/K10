<?php
session_start ();
error_reporting(0);
$usersesion = $_SESSION['usuario'];
if  ($usersesion == null || $usersesion ='' ){
echo 'usted no puede ingresar, por favor registrese';
die();
}
?>
<!DOCTYPE html>
<html>
<head><meta charset="utf-8">
<title>Bienvenidos | K10</title>
<link rel="icon" type="icon" href="material/k101.png">
<link rel="stylesheet" href="css/font.css">
<link rel="stylesheet" href="css/fuentes.css">
<link rel="stylesheet" href="iconos/iconos.css">

<link rel="stylesheet" href="css/contenido.css">
<link rel="stylesheet" href="css/slider.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script></head><header><nav class="menu">
<div class="enlaces" id="enlaces"> <a href="bienvenidos.php"><u>Bienvenido <span class="icon-home"></span></u></a>
<a href="instrucciones.php">Instrucciones <span class="icon-tools"></span></a></div><div class="logo">
<a href="pago.php"><img src="material/K10C2.png" alt="k10"></div></a><div class="enlaces" id="enlaces">
<a href="acercade.php">Acerca de k10 <span class="icon-man"></span></a><a href="xsession.php">cerrar sesión <span class="icon-power-plug"></span></a></div></nav>
</header><body>
<div class="net"><a href="https://mail.google.com/mail/u/0/#inbox" class="icon icon-google" target="_blank"></a><a href="https://www.facebook.com/fernandocuatrorivera" class="icon icon-facebook2" target="_blank"></a>
<a href="https://www.instagram.com/fernandocuatro.jpg/" class="icon icon-instagram" target="_blank"></a><a href="tel:+50364229837" class="icon icon-whatsapp" target="_blank"></a>
<a href="https://twitter.com/FernandoCuatro" class="icon icon-twitter" target="_blank"></a></div><div class="Papel">
<article><h2>¡Hola <?php echo $_SESSION['usuario'] ?>!<span class="icon-man"></h2><center><hr width="80%"/></center><h1>¡Bienvenido a la Loteria K10</h1><br><hr ><p><div class="slider"><ul>
<li><img src="material/1.jpeg" alt="K10 (1)" ></li><li><img src="material/2.jpeg" alt="K10 (2)" ></li><li><img src="material/3.jpeg" alt="K10 (3)" ></li><li><img src="material/4.jpeg" alt="K10 (4)" ></li>
</ul></div><br><hr ><hr ><p></p><br><h2>¿Que es la loteria?</h2>
El juego de la lotería, ampliamente difundido en México, es un juego de azar que consta de un bonche de 54 cartas (en nuestro caso 30 cartas) y un número
indefinido de tarjetas llamadas "tablas" con 16 de dichas cartas escogidas aleatoriamente. Cada vez que se extraiga una carta del
bonche, ésta se anuncia y los participantes deben marcar esa carta en sus tablas si la tienen. El ganador será quien primero forme 
en su tabla la alineación que se haya especificado al inicio del juego con las cartas marcadas y grite "lotería". La palabra que se grita
al momento de ganar varia dependiendo región del país, en Estados Unidos se grita "Bingo!", En el norte de país de México se grita 
"Buenas!" , mientras que en los lugares sureños del país tienden a gritar el original "Lotería".<p><br><h3> Algunas cartas que veras son las siguientes:</h3><br>
<script type="text/javascript"> var sliderwidth="930px"; var sliderheight="180px"; var slidespeed=4; slidebgcolor="#f2f2f2"; var leftrightslide=new Array(); var finalslide=''
leftrightslide[0]='<a  title=""><img border="0" src="cartas/1.png" height="180"></a>'
leftrightslide[1]='<a title=""><img border="0" src="cartas/2.png" height="180"></a>'
leftrightslide[2]='<a title=""><img border="0" src="cartas/3.png" height="180"></a>'
leftrightslide[3]='<a title=""><img border="0" src="cartas/4.png" height="180"></a>'
leftrightslide[4]='<a title=""><img border="0" src="cartas/5.png" height="180"></a>'
leftrightslide[5]='<a title=""><img border="0" src="cartas/6.png" height="180"></a>'
leftrightslide[6]='<a title=""><img border="0" src="cartas/7.png" height="180"></a>'
leftrightslide[7]='<a title=""><img border="0" src="cartas/8.png" height="180"></a>'
leftrightslide[8]='<a title="t"><img border="0" src="cartas/9.png" height="180"></a>'
leftrightslide[9]='<a title=""><img border="0" src="cartas/10.png" height="180"></a>'
leftrightslide[10]='<a title=""><img border="0" src="cartas/11.png" height="180"></a>'
leftrightslide[11]='<a title=""><img border="0" src="cartas/12.png" height="180"></a>'
leftrightslide[12]='<a title=""><img border="0" src="cartas/13.png" height="180"></a>'
leftrightslide[13]='<a title=""><img border="0" src="cartas/14.png" height="180"></a>'
leftrightslide[14]='<a title=""><img border="0" src="cartas/15.png" height="180"></a>';
leftrightslide[15]='<a title=""><img border="0" src="cartas/16.png" height="180"></a>';
leftrightslide[16]='<a title=""><img border="0" src="cartas/17.png" height="180"></a>';
leftrightslide[17]='<a title=""><img border="0" src="cartas/18.png" height="180"></a>';
leftrightslide[18]='<a title=""><img border="0" src="cartas/19.png" height="180"></a>';
leftrightslide[19]='<a title=""><img border="0" src="cartas/20.png" height="180"></a>';
leftrightslide[20]='<a title=""><img border="0" src="cartas/21.png" height="180"></a>';
leftrightslide[21]='<a title=""><img border="0" src="cartas/22.png" height="180"></a>';
leftrightslide[22]='<a title=""><img border="0" src="cartas/23.png" height="180"></a>';
leftrightslide[23]='<a title=""><img border="0" src="cartas/24.png" height="180"></a>';
leftrightslide[24]='<a title=""><img border="0" src="cartas/25.png" height="180"></a>';
leftrightslide[25]='<a title=""><img border="0" src="cartas/26.png" height="180"></a>';
leftrightslide[26]='<a title=""><img border="0" src="cartas/27.png" height="180"></a>';
leftrightslide[27]='<a title=""><img border="0" src="cartas/28.png" height="180"></a>';
leftrightslide[28]='<a title=""><img border="0" src="cartas/29.png" height="180"></a>';
leftrightslide[29]='<a title=""><img border="0" src="cartas/30.png" height="180"></a>';
var imagegap=""; var slideshowgap=15
var copyspeed=slidespeed
leftrightslide='<nobr>'+leftrightslide.join(imagegap)+'</nobr>'
var iedom=document.all||document.getElementById
if (iedom)
document.write('<span id="temp" style="visibility:hidden;position:absolute;top:-100px;left:-9000px">'+leftrightslide+'</span>')
var actualwidth=''
var cross_slide, ns_slide
function fillup(){
if (iedom){
cross_slide=document.getElementById? document.getElementById("test2") : document.all.test2
cross_slide2=document.getElementById? document.getElementById("test3") : document.all.test3
cross_slide.innerHTML=cross_slide2.innerHTML=leftrightslide
actualwidth=document.all? cross_slide.offsetWidth : document.getElementById("temp").offsetWidth
cross_slide2.style.left=actualwidth+slideshowgap+"px"
}
else if (document.layers){
ns_slide=document.ns_slidemenu.document.ns_slidemenu2
ns_slide2=document.ns_slidemenu.document.ns_slidemenu3
ns_slide.document.write(leftrightslide)
ns_slide.document.close()
actualwidth=ns_slide.document.width
ns_slide2.left=actualwidth+slideshowgap
ns_slide2.document.write(leftrightslide)
ns_slide2.document.close()
}
lefttime=setInterval("slideleft()",30)
}
window.onload=fillup
function slideleft(){
if (iedom){
if (parseInt(cross_slide.style.left)>(actualwidth*(-1)+8))
cross_slide.style.left=parseInt(cross_slide.style.left)-copyspeed+"px"
else
cross_slide.style.left=parseInt(cross_slide2.style.left)+actualwidth+slideshowgap+"px"
if (parseInt(cross_slide2.style.left)>(actualwidth*(-1)+8))
cross_slide2.style.left=parseInt(cross_slide2.style.left)-copyspeed+"px"
else
cross_slide2.style.left=parseInt(cross_slide.style.left)+actualwidth+slideshowgap+"px"
}
else if (document.layers){
if (ns_slide.left>(actualwidth*(-1)+8))
ns_slide.left-=copyspeed
else
ns_slide.left=ns_slide2.left+actualwidth+slideshowgap
if (ns_slide2.left>(actualwidth*(-1)+8))
ns_slide2.left-=copyspeed
else
ns_slide2.left=ns_slide.left+actualwidth+slideshowgap
}
}
if (iedom||document.layers){
with (document){
document.write('<table border="0" cellspacing="0" cellpadding="0"><td>')
if (iedom){
write('<div style="position:relative;width:'+sliderwidth+';height:'+sliderheight+';overflow:hidden">')
write('<div style="position:absolute;width:'+sliderwidth+';height:'+sliderheight+';background-color:'+slidebgcolor+'" onmouseover="copyspeed=0" onmouseout="copyspeed=slidespeed">')
write('<div id="test2" style="position:absolute;left:0px;top:0px"></div>')
write('<div id="test3" style="position:absolute;left:-1000px;top:0px"></div>')
write('</div></div>')
}
else if (document.layers){
write('<ilayer width="+sliderwidth+" height="+sliderheight+" name="ns_slidemenu" bgcolor="+slidebgcolor+">')
write('<layer left="0" top="0" onmouseover="copyspeed=0" onmouseout="copyspeed=slidespeed" name="ns_slidemenu2"></layer>')
write('<layer left="0" top="0" onmouseover="copyspeed=0" onmouseout="copyspeed=slidespeed" name="ns_slidemenu3"></layer>')
write('</ilayer>')
}
document.write('</td></table>')
}
}</script><p></p><br><table class="tabla"><tr><td>1. El gallo<br>El que la cantó a San Pedro</td><td>2. El diablo<br>Pórtate bien cuatito, si no te lleva el coloradito.</td>
<td>3. La dama.<br>Puliendo el paso, por toda la calle real.</td></tr><tr><td>4 El catrín<br>Don Ferruco en la alameda. Inspirado en Don Memo (conocido por su elegancia ).</td>
<td>5 El paraguas<br>Para el sol y para el agua.</td><td>6 La sirena<br>Medio cuerpo de señora se divisa en altamar.</td></tr><tr><td>7 La escalera<br>
Súbeme paso a pasito, no quieras pegar brinquitos.</td><td>8 La botella<br>La herramienta del borracho.</td><td>9 El barril<br>Tanto bebió el albañil, que quedó como barril.</td></tr>
<tr><td>10 El árbol<br>El que a buen árbol se arrima buena sombra le cobija.</td><td>11 El melón<br>Me lo das o me lo quitas.</td><td>12 El valiente<br>
a esta carta se le quería cambiar el nombre por El Piero</td></tr><tr><td>13 El gorrito<br>El gorrito que me ponenPonle su gorrito al nene, no se nos vaya a resfriar.</td><td>14 La muerte<br>La muerte siriqui siaca.</td>
<td>15 La pera<br>El que espera desespera.</td></tr><tr><td>16 La bandera<br>Verde blanco y colorado, la bandera del soldado.</td>
<td>17 El bandolón<br>Tocando su bandolón, está el mariachi Simón.</td><td>18 El violoncello<br>Creciendo se fue hasta el cielo, y como no fue violín, tuvo que ser violoncello.</td></tr><tr>
<td>19 La garza<br>Al otro lado del río tengo mi banco de arena.</td><td>20 El pájaro<br>Tu me traes a puros brincos, como pájaro en la rama.</td><td>21 La mano<br>
La mano de un criminal.</td></tr><tr><td>22 La bota<br>Una bota igual que l'otra.</td><td>23 La luna<br>El farol de los enamorados.</td><td>24 El cotorro<br>Cotorro cotorro saca la pata, y empiézame a platicar.</td></tr><tr><td>25 El borracho<br>
¡Ah! qué borracho tan necio, ya no lo puedo aguantar.</td><td>26 El negrito<br>El que se comió el azúcar.</td><td>27 El corazón<br>
No me extrañes corazón, que regresó en el camión.</td></tr><tr><td>28 La sandía<br>La barriga que Juan tenía, era empacho de sandía.</td><td>29 El tambor<br>No te arrugues cuero viejo, que te quiero pa'tambor.</td><td>30 El camarón<br>
Camarón que se duerme, se lo lleva la corriente.</td></tr></table><p></p><hr><br><div class="fin">
<h4> ¿Adonde quieres ir? </h4><p><a href="instrucciones.php"><button class="primero">Instrucciones <span class="icon-tools" id="iconnos"></span></button></a>
<a href="acercade.php"><button class="primero">Acerca de <span class="icon-user" id="iconnos"></span></button></a></div></article></div>  
<footer>
<section id="acerca de"><h1><img src="material/k105.png"  width="201px" alt="k10"></h1>
<section id class="Final">
Copyright © Corporacion
</id></footer>
</body>
</html>