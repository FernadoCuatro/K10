CREATE DATABASE loteria2;
use loteria2;
CREATE TABLE `registro` (
`NomUser` varchar(25) PRIMARY KEY NOT NULL,
`Nombre` varchar(25) NOT NULL,
`Apellido` varchar(15) NOT NULL,
`Clave` varchar(10)  NOT NULL,
`edad` int(11) NOT NULL,
`correo` varchar(45) NOT NULL,
`genero` varchar(9) NOT NULL
);
