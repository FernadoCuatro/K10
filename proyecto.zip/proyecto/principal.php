<?php
session_start();
$usersesion = $_SESSION['usuario'];
if(isset($_SESSION["user"])){
		if($_SESSION["user"] == ""){
			
		}else{
			header("location: usuario/index.php");
		}
}else{


}
?>
<!DOCTYPE html>
<html>
<head>
<title>Juega | K10</title>
<link rel="icon" type="icon" href="material/k101.png">
<link rel="stylesheet" href="css/font.css">
<link rel="stylesheet" href="css/fuentes.css">
<link rel="stylesheet" type="text/css" href="css/inicio.css">
<link rel="stylesheet" href="iconos/iconos.css">
</head>
<body>
<center>
<div class="net">
	<a href="https://mail.google.com/mail/u/0/#inbox" class="icon icon-google" target="_blank"></a><a href="https://www.facebook.com/fernandocuatrorivera" class="icon icon-facebook2" target="_blank"></a>
<a href="https://www.instagram.com/fernandocuatro.jpg/" class="icon icon-instagram" target="_blank"></a><a href="tel:+50364229837" class="icon icon-whatsapp" target="_blank"></a>
<a href="http://localhost/admonPHP/Union/admin/" class="icon icon-twitter" target="_blank"></a></div>

<form method="post" action="usuario/validar.php" >
<h1>¡Gracias  <?php echo $_SESSION['usuario'] ?> juega con  <br>tu nombre preferido!<span class="icon-game-controller" id="iconnos"></span></h1>
<input type="text" name="nm" placeholder="Nombre"  required><br><br>
<input type="text" name="ap" placeholder="Apellido" required><br><br>
<input type="submit" name="bt" value="Enviar" id="boton">
<a href="pago.php"><input type="button" value="regresar"></a>
</form>
</center>
</body>
</html>