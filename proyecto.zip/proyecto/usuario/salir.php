<?php
session_start();
$_SESSION["car"] = "";
$_SESSION["user"] = "";
header("location: ../principal.php");
?>