<?php
session_start ();
error_reporting(0);
$usersesion = $_SESSION['usuario'];
if  ($usersesion == null || $usersesion ='' ){
echo 'usted no puede ingresar, por favor registrese';
die(); }?>
<!DOCTYPE html>
<html>
<head><meta charset="utf-8">
<title>Pago | K10</title>
<link rel="icon" type="icon" href="material/k101.png">
<link rel="stylesheet" href="css/font.css">
<link rel="stylesheet" href="css/pago.css">
<link rel="stylesheet" href="css/fuentes.css">
<link rel="stylesheet" href="iconos/iconos.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script></head><header><nav class="menu">
<div class="enlaces" id="enlaces"> <a href="bienvenidos.php">Bienvenido <span class="icon-laptop"></span></a>
<a href="instrucciones.php">Instrucciones <span class="icon-attachment"></span></a></div><div class="logo">
<a href="pago.php"><img src="" alt=""></div></a><div class="enlaces" id="enlaces">
<a href="acercade.php">Acerca de k10 <span class="icon-location-pin"></span></a><a href="xsession.php">cerrar sesión <span class="icon-emoji-sad"></span></a></div></nav>
</header><body>
<div class="net"><a href="https://mail.google.com/mail/u/0/#inbox" class="icon icon-google" target="_blank"></a><a href="https://www.facebook.com/fernandocuatrorivera" class="icon icon-facebook2" target="_blank"></a>
<a href="https://www.instagram.com/fernandocuatro.jpg/" class="icon icon-instagram" target="_blank"></a><a href="tel:+50364229837" class="icon icon-whatsapp" target="_blank"></a>
<a href="https://twitter.com/FernandoCuatro" class="icon icon-twitter" target="_blank"></a></div><div class="Papel">
<article>
<h3>¡Hola, <u><?php echo $_SESSION['usuario'] ?></u>!<span class="icon-heart"></h3><br><h3>Es un gusto tenerte aqui, para poder jugar, tienes que pagar un monto economico<span class="icon-check"></h3>
<br><h3>¡Este mes de <b><big>Octubre</big></b> tenemos para ti 15 dias de prueba gratis!<span class="icon-game-controller">.</h3>&nbsp;<p>&nbsp;<p><div id="espacio"><div class="pago">
	<div class="targeta"><div class="titulo">Cancela el servicio k10</div>
<div class="segundo"><span class="card">Numero de targeta</span>
<div class="space"><input type="text" maxlength="4" name="number-card" placeholder="0000" required="required"/>
<input type="text" maxlength="4" name="number-card" placeholder="0000" required="required"/>
<input type="text" maxlength="4" name="number-card" placeholder="0000" required="required"/>
<input type="text" maxlength="4" name="number-card" placeholder="0000" required="required"/></div>
<div class="cvv"><div class="cvc"><span>CVV o CVC</span><div class="space"><input type="text" maxlength="4" name="number-card" placeholder="xxx-x" required="required"/></div>
</select></div></div></div><div class="chip"><div class=""><div class=""><div class=""> </div><div class=""> </div>
</div></div></div><div class="nombre"><span>Thank you for helping us</span></div></div>
<div class=""><div class=""></div><div class=""></div></div></div>&nbsp;<p>&nbsp;<p><table class="tabla"><tr><td><a href="principal.php">¡Gratis 15 dias de prueba!</td></a>
<td><a > ¡Cancela $15.99 por 6 meses!</td></a><td><a > ¡Cancela $25.99 por 12 meses!</a></td></tr></table>
&nbsp;<p>&nbsp;<p><div class="fin"><h4> ¿Adonde quieres ir? </h4><p><a href="bienvenidos.php"><button class="primero">Bienvenidos <span class="icon-laptop" id="iconnos"></span></button></a>
<a href="instrucciones.php"><button class="primero">Instrucciones <span class="icon-attachment" id="iconnos"></span></button></a>
<a href="acercade.php"><button class=	"primero">Acerca de  <span class="icon-location-pin" id="iconnos"></span></button></a></div></article></div>  
<footer><section id="acerca de"><h1><img src="material/k108.png"  width="201px" alt="k10"></h1>
<section id class="Final">
Copyright © Corporacion
</id></footer>
</body>
</html>