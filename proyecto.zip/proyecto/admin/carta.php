<?php
$card = 0;
if (isset($_GET['card'])) {
	$card = $_GET['card'];
	for ($i= $card; $i >= 1 ; $i--) { 

		if($i == $card){
			?>

			<?php
		}else{
			?>
			<style type="text/css">
		    <?php echo '#card'.$i?>{
			display: none;
				}
			</style>
			<?php
		}
		
	}

}
$carta = mt_rand(1,30);
	echo "<div id='card$card'>";
echo "<img src='../media/img/$carta.jpg' id='crt'>";
echo "<embed loop='false' src='../media/audio/$carta.wav' hidden='true' autoplay='true'></embed>";
	echo "</div>";

?>
<style type="text/css">
	<?php echo '#c'.$carta?>{
		filter: brightness(20%);
	}
</style>

