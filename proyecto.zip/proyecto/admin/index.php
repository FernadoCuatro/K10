<!DOCTYPE html>
<html>
<head>
	<title>Administrador | K10</title>
	<link rel="stylesheet" type="text/css" href="../css/cartas.css">
</head>
<body>
<?php 
require "../conn/conexion.php";

$sql = "SELECT Id, c1, c2,c3, c4, c5, c6, c7, c8, c9, estado FROM carton where estado='1'";
$result = $conexion->query($sql);

if($result->num_rows > 0){
while ($row = $result->fetch_assoc()) {
if ($row["estado"] == 1) {
echo "<table border='1' class='reser'>";
}else{
echo "<table border='1'>";
}
?>
<tr>
<th colspan="3"><?php echo "carton: ".$row["Id"]; ?></th>
</tr>
<tr>
				<td><img id="<?php echo 'c'.$row['c1'];?>" src="../media/img/<?php echo $row['c1'].'.jpg'; ?>"></td>
				<td><img id="<?php echo 'c'.$row['c2'];?>" src="../media/img/<?php echo $row['c2'].'.jpg'; ?>"></td>
				<td><img id="<?php echo 'c'.$row['c3'];?>" src="../media/img/<?php echo $row['c3'].'.jpg'; ?>"></td>
			</tr>
			<tr>
				<td><img id="<?php echo 'c'.$row['c4'];?>" src="../media/img/<?php echo $row['c4'].'.jpg'; ?>"></td>
				<td><img id="<?php echo 'c'.$row['c5'];?>" src="../media/img/<?php echo $row['c5'].'.jpg'; ?>"></td>
				<td><img id="<?php echo 'c'.$row['c6'];?>" src="../media/img/<?php echo $row['c6'].'.jpg'; ?>"></td>
			</tr>
			<tr>
				<td><img id="<?php echo 'c'.$row['c7'];?>" src="../media/img/<?php echo $row['c7'].'.jpg'; ?>"></td>
<td><img id="<?php echo 'c'.$row['c8'];?>" src="../media/img/<?php echo $row['c8'].'.jpg'; ?>"></td>
<td><img id="<?php echo 'c'.$row['c9'];?>" src="../media/img/<?php echo $row['c9'].'.jpg'; ?>"></td>
</tr>
<?php
echo "</table>";
}
}

?>
<script type="text/javascript" src='../js/ajx.js'></script>
<div class="cartas">
<center>	
<button onclick="carta();">mostrar carta</button>  <a href="refre.php"><button style="float: right;">Listo</button></a><a href="javascript:window.close();"><button style="float: left;">Salir</button></a> 
<div id="carta" style="width: 50vw;text-align: center;">
	
  </div>

</center>
</div>
</body>
</html>