<?php
$cartaRamdom = array();
$cartaRamdomPrimera = mt_rand(1,30);
array_push($cartaRamdom, $cartaRamdomPrimera);
$x = 1;
while ($x < 2){
$SiguienteCartaRamdom = mt_rand(1, 30);
if(in_array($SiguienteCartaRamdom, $cartaRamdom)){
continue;
}else{
array_push($cartaRamdom, $SiguienteCartaRamdom);
$baraja = "<img src='Material/".$cartaRamdom[$x].".jpg' height=230px ";
$x++;
$self = $_SERVER['PHP_SELF'];
header("refresh:3; url=$self");
}
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Loteria</title>
	<link rel="stylesheet" type="text/css" media="screen" href="css/modelo.css" />
</head>
<body>
	
<div class="cuarta"> 
<table>
<tr>
<td><?php echo $baraja; ?></td>
</tr>
</table> 
</div>
</body>
</html>