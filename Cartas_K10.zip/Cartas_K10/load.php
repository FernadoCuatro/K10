<html>
<head>
<title>Loteria</title>
<link rel="stylesheet" href="css/modelo.css">
<?php
function roll(){
return mt_rand(1,15);
}$seleccionado=roll(); $sele=roll(); $sel=roll();
if($seleccionado==1){
$tablero1[0]="1";
$tablero1[1]="2";
$tablero1[2]="3";
$tablero1[3]="4";
$tablero1[4]="5";
$tablero1[5]="6";
$tablero1[6]="7";
$tablero1[7]="8";
$tablero1[8]="9";
}else if($seleccionado==2){
$tablero1[0]="10";
$tablero1[1]="11";
$tablero1[2]="12";
$tablero1[3]="13";
$tablero1[4]="14";
$tablero1[5]="15";
$tablero1[6]="16";
$tablero1[7]="17";
$tablero1[8]="18";
}else if($seleccionado==3){
$tablero1[0]="19";
$tablero1[1]="20";
$tablero1[2]="21";
$tablero1[3]="22";
$tablero1[4]="23";
$tablero1[5]="24";
$tablero1[6]="25";
$tablero1[7]="26";
$tablero1[8]="27";
}else if($seleccionado==4){
$tablero1[0]="28";
$tablero1[1]="29";
$tablero1[2]="30";
$tablero1[3]="11";
$tablero1[4]="24";
$tablero1[5]="20";
$tablero1[6]="17";
$tablero1[7]="27";
$tablero1[8]="16";
}else if($seleccionado==5){
$tablero1[0]="14";
$tablero1[1]="11";
$tablero1[2]="13";
$tablero1[3]="30";
$tablero1[4]="21";
$tablero1[5]="12";
$tablero1[6]="23";
$tablero1[7]="4";
$tablero1[8]="15";
}else if($seleccionado==6){
$tablero1[0]="19";
$tablero1[1]="10";
$tablero1[2]="6";
$tablero1[3]="21";
$tablero1[4]="28";
$tablero1[5]="1";
$tablero1[6]="19";
$tablero1[7]="4";
$tablero1[8]="17";
}else if($seleccionado==7){
$tablero1[0]="1";
$tablero1[1]="12";
$tablero1[2]="27";
$tablero1[3]="6";
$tablero1[4]="11";
$tablero1[5]="29";
$tablero1[6]="8";
$tablero1[7]="19";
$tablero1[8]="20";
}else if($seleccionado==8){
$tablero1[0]="2";
$tablero1[1]="11";
$tablero1[2]="23";
$tablero1[3]="16";
$tablero1[4]="27";
$tablero1[5]="22";
$tablero1[6]="29";
$tablero1[7]="30";
$tablero1[8]="18";
}else if($seleccionado==9){
$tablero1[0]="30";
$tablero1[1]="1";
$tablero1[2]="27";
$tablero1[3]="12";
$tablero1[4]="26";
$tablero1[5]="22";
$tablero1[6]="3";
$tablero1[7]="5";
$tablero1[8]="16";
}else if($seleccionado==10){
$tablero1[0]="9"; 
$tablero1[1]="26";
$tablero1[2]="7";
$tablero1[3]="10"; 
$tablero1[4]="24";
$tablero1[5]="1";
$tablero1[6]="22";
$tablero1[7]="8";
$tablero1[8]="28";
}else if($seleccionado==11){
$tablero1[0]="17";
$tablero1[1]="26";
$tablero1[2]="8";
$tablero1[3]="19";
$tablero1[4]="22";
$tablero1[5]="21";
$tablero1[6]="18";
$tablero1[7]="15";
$tablero1[8]="2";
}else if($seleccionado==12){
$tablero1[0]="25";
$tablero1[1]="7";
$tablero1[2]="9";
$tablero1[3]="23";
$tablero1[4]="17";
$tablero1[5]="3";
$tablero1[6]="9";
$tablero1[7]="2";
$tablero1[8]="24";
}else if($seleccionado==13){
$tablero1[0]="10";
$tablero1[1]="16";
$tablero1[2]="19";
$tablero1[3]="27";
$tablero1[4]="13";
$tablero1[5]="23";
$tablero1[6]="17";
$tablero1[7]="28";
$tablero1[8]="1";
}else if($seleccionado==14){
$tablero1[0]="10";
$tablero1[1]="13";
$tablero1[2]="18";
$tablero1[3]="24";
$tablero1[4]="1";
$tablero1[5]="26";
$tablero1[6]="7";
$tablero1[7]="6";
$tablero1[8]="11";
}else if($seleccionado==15){
$tablero1[0]="21";
$tablero1[1]="10";
$tablero1[2]="14";
$tablero1[3]="7";
$tablero1[4]="14";
$tablero1[5]="23";
$tablero1[6]="9";
$tablero1[7]="12";
$tablero1[8]="28";
}if($sele==1){
$tablero2[8]="1";
$tablero2[7]="2";
$tablero2[6]="3";
$tablero2[5]="4";
$tablero2[4]="5";
$tablero2[3]="6";
$tablero2[2]="7";
$tablero2[1]="8";
$tablero2[0]="9";
}else if($sele==2){
$tablero2[8]="10";
$tablero2[7]="11";
$tablero2[6]="12";
$tablero2[5]="13";
$tablero2[4]="14";
$tablero2[3]="15";
$tablero2[2]="16";
$tablero2[1]="17";
$tablero2[0]="18";
}else if($sele==3){
$tablero2[8]="19";
$tablero2[7]="20";
$tablero2[6]="21";
$tablero2[5]="22";
$tablero2[4]="23";
$tablero2[3]="24";
$tablero2[2]="25";
$tablero2[1]="26";
$tablero2[0]="27";
}else if($sele==4){
$tablero2[8]="28";
$tablero2[7]="29";
$tablero2[6]="30";
$tablero2[5]="11";
$tablero2[4]="24";
$tablero2[3]="20";
$tablero2[2]="17";
$tablero2[1]="27";
$tablero2[0]="16";
}else if($sele==5){
$tablero2[8]="14";
$tablero2[7]="11";
$tablero2[6]="13";
$tablero2[5]="30";
$tablero2[4]="21";
$tablero2[3]="12";
$tablero2[2]="23";
$tablero2[1]="4";
$tablero2[0]="15";
}else if($sele==6){
$tablero2[8]="19";
$tablero2[7]="10";
$tablero2[6]="6";
$tablero2[5]="21";
$tablero2[4]="28";
$tablero2[3]="1";
$tablero2[2]="28";
$tablero2[1]="4";
$tablero2[0]="17";
}else if($sele==7){
$tablero2[8]="1";
$tablero2[7]="12";
$tablero2[6]="27";
$tablero2[5]="6";
$tablero2[4]="11";
$tablero2[3]="29";
$tablero2[2]="8";
$tablero2[1]="19";
$tablero2[0]="20";
}else if($sele==8){
$tablero2[8]="2";
$tablero2[7]="11";
$tablero2[6]="23";
$tablero2[5]="16";
$tablero2[4]="27";
$tablero2[3]="22";
$tablero2[2]="29";
$tablero2[1]="30";
$tablero2[0]="18";
}else if($sele==9){
$tablero2[8]="30";
$tablero2[7]="1";
$tablero2[6]="27";
$tablero2[5]="12";
$tablero2[4]="26";
$tablero2[3]="22";
$tablero2[2]="3";
$tablero2[1]="5";
$tablero2[0]="16";
}else if($sele==10){
$tablero2[8]="9";
$tablero2[7]="26";
$tablero2[6]="7";
$tablero2[5]="10";
$tablero2[4]="24";
$tablero2[3]="1";
$tablero2[2]="22";
$tablero2[1]="8";
$tablero2[0]="28";
}else if($sele==11){
$tablero2[8]="17";
$tablero2[7]="26";
$tablero2[6]="8";
$tablero2[5]="19";
$tablero2[4]="22";
$tablero2[3]="21";
$tablero2[2]="18";
$tablero2[1]="15";
$tablero2[0]="2";
}else if($sele==12){
$tablero2[8]="25";
$tablero2[7]="7";
$tablero2[6]="9";
$tablero2[5]="23";
$tablero2[4]="17";
$tablero2[3]="3";
$tablero2[2]="9";
$tablero2[1]="2";
$tablero2[0]="24";
}else if($sele==13){
$tablero2[8]="10";
$tablero2[7]="16";
$tablero2[6]="19";
$tablero2[5]="27";
$tablero2[4]="13";
$tablero2[3]="23";
$tablero2[2]="17";
$tablero2[1]="28";
$tablero2[0]="1";
}else if($sele==14){
$tablero2[8]="10";
$tablero2[7]="13";
$tablero2[6]="18";
$tablero2[5]="24";
$tablero2[4]="1";
$tablero2[3]="26";
$tablero2[2]="7";
$tablero2[1]="6";
$tablero2[0]="11";
}else if($sele==15){
$tablero2[8]="21";
$tablero2[7]="10";
$tablero2[6]="14";
$tablero2[5]="7";
$tablero2[4]="14";
$tablero2[3]="23";
$tablero2[2]="9";
$tablero2[1]="12";
$tablero2[0]="28";
}if($sel==1){
$tablero3[7]="1";
$tablero3[4]="2";
$tablero3[2]="3";
$tablero3[0]="4";
$tablero3[1]="5";
$tablero3[3]="6";
$tablero3[5]="7";
$tablero3[8]="8";
$tablero3[6]="9";
}else if($sel==2){
$tablero3[7]="10";
$tablero3[4]="11";
$tablero3[2]="12";
$tablero3[0]="13";
$tablero3[1]="14";
$tablero3[3]="15";
$tablero3[5]="16";
$tablero3[8]="17";
$tablero3[6]="18";
}else if($sel==3){
$tablero3[7]="19";
$tablero3[4]="20";
$tablero3[2]="21";
$tablero3[0]="22";
$tablero3[1]="23";
$tablero3[3]="24";
$tablero3[5]="25";
$tablero3[8]="26";
$tablero3[6]="27";
}else if($sel==4){
$tablero3[7]="28";
$tablero3[4]="29";
$tablero3[2]="30";
$tablero3[0]="11";
$tablero3[1]="24";
$tablero3[3]="20";
$tablero3[5]="17";
$tablero3[8]="27";
$tablero3[6]="16";
}else if($sel==5){
$tablero3[7]="14";
$tablero3[4]="11";
$tablero3[2]="13";
$tablero3[0]="30";
$tablero3[1]="21";
$tablero3[3]="12";
$tablero3[5]="23";
$tablero3[8]="4";
$tablero3[6]="15";
}else if($sel==6){
$tablero3[7]="19";
$tablero3[4]="10";
$tablero3[2]="6";
$tablero3[0]="21";
$tablero3[1]="28";
$tablero3[3]="1";
$tablero3[5]="28";
$tablero3[8]="4";
$tablero3[6]="17";
}else if($sel==7){
$tablero3[7]="1";
$tablero3[4]="12";
$tablero3[2]="27";
$tablero3[0]="6";
$tablero3[1]="11";
$tablero3[3]="29";
$tablero3[5]="8";
$tablero3[8]="19";
$tablero3[6]="20";
}else if($sel==8){
$tablero3[7]="2";
$tablero3[4]="11";
$tablero3[2]="23";
$tablero3[0]="16";
$tablero3[1]="27";
$tablero3[3]="22";
$tablero3[5]="29";
$tablero3[8]="30";
$tablero3[6]="18";
}else if($sel==9){
$tablero3[7]="30";
$tablero3[4]="1";
$tablero3[2]="27";
$tablero3[0]="12";
$tablero3[1]="26";
$tablero3[3]="22";
$tablero3[5]="3";
$tablero3[8]="5";
$tablero3[6]="16";
}else if($sel==10){
$tablero3[7]="9";
$tablero3[4]="26";
$tablero3[2]="7";
$tablero3[0]="10";
$tablero3[1]="24";
$tablero3[3]="1";
$tablero3[5]="22";
$tablero3[8]="8";
$tablero3[6]="28";
}else if($sel==11){
$tablero3[7]="17";
$tablero3[4]="26";
$tablero3[2]="8";
$tablero3[0]="19";
$tablero3[1]="22";
$tablero3[3]="21";
$tablero3[5]="18";
$tablero3[8]="15";
$tablero3[6]="2";
}else if($sel==12){
$tablero3[7]="25";
$tablero3[4]="7";
$tablero3[2]="9";
$tablero3[0]="23";
$tablero3[1]="17";
$tablero3[3]="3";
$tablero3[5]="9";
$tablero3[8]="2";
$tablero3[6]="24";
}else if($sel==13){
$tablero3[7]="10";
$tablero3[4]="16";
$tablero3[2]="19";
$tablero3[0]="27";
$tablero3[1]="13";
$tablero3[3]="23";
$tablero3[5]="17";
$tablero3[8]="28";
$tablero3[6]="1";
}else if($sel==14){
$tablero3[7]="10";
$tablero3[4]="13";
$tablero3[2]="18";
$tablero3[0]="24";
$tablero3[1]="1";
$tablero3[3]="26";
$tablero3[5]="7";
$tablero3[8]="6";
$tablero3[6]="11";
}else if($sel==15){
$tablero3[7]="21";
$tablero3[4]="10";
$tablero3[2]="14";
$tablero3[0]="7";
$tablero3[1]="14";
$tablero3[3]="23";
$tablero3[5]="9";
$tablero3[8]="12";
$tablero3[6]="28";
}?></head>
<body class="fondo1">
<div class="reproductor">
<audio controls>
<source src="Sonidos/Fondo1.mp3" type="audio/mpeg">
<source src="Sonidos/Fondo.wav" type="audio/wav">
</audio></div>

<div class="primera"><h1>Tablero #<?php echo $seleccionado;?></h1><table><tr>
<td><img src='Material/<?php echo $tablero1[0];?>.jpg' height="120px"></td>
<td><img src='Material/<?php echo $tablero1[1];?>.jpg' height="120px"></td>
<td><img src='Material/<?php echo $tablero1[2];?>.jpg' height="120px"></td></tr><tr>
<td><img src='Material/<?php echo $tablero1[3];?>.jpg' height="120px"></td>
<td><img src='Material/<?php echo $tablero1[4];?>.jpg' height="120px"></td>
<td><img src='Material/<?php echo $tablero1[5];?>.jpg' height="120px"></td></tr><tr>
<td><img src='Material/<?php echo $tablero1[6];?>.jpg' height="120px"></td>
<td><img src='Material/<?php echo $tablero1[7];?>.jpg' height="120px"></td>
<td><img src='Material/<?php echo $tablero1[8];?>.jpg' height="120px"></td></tr></table>
<div class="segunda"><h1>Tablero #<?php echo $sele;?></h1><table><tr>
<td><img src='Material/<?php echo $tablero2[0];?>.jpg' height="120px" ></td>
<td><img src='Material/<?php echo $tablero2[1];?>.jpg' height="120px" ></td>
<td><img src='Material/<?php echo $tablero2[2];?>.jpg' height="120px" ></td></tr><tr>
<td><img src='Material/<?php echo $tablero2[3];?>.jpg' height="120px" ></td>
<td><img src='Material/<?php echo $tablero2[4];?>.jpg' height="120px" ></td>
<td><img src='Material/<?php echo $tablero2[5];?>.jpg' height="120px" ></td></tr><tr>
<td><img src='Material/<?php echo $tablero2[6];?>.jpg' height="120px" ></td>
<td><img src='Material/<?php echo $tablero2[7];?>.jpg' height="120px" ></td>
<td><img src='Material/<?php echo $tablero2[8];?>.jpg' height="120px"  ></td></tr></table></div>
<div class="tercera"><h1>Tablero #<?php echo $sel;?></h1><table><tr>
<td><img src='Material/<?php echo $tablero3[0];?>.jpg' height="120px" ></td>
<td><img src='Material/<?php echo $tablero3[1];?>.jpg' height="120px" ></td>
<td><img src='Material/<?php echo $tablero3[2];?>.jpg' height="120px" ></td></tr><tr>
<td><img src='Material/<?php echo $tablero3[3];?>.jpg' height="120px" ></td>
<td><img src='Material/<?php echo $tablero3[4];?>.jpg' height="120px" ></td>
<td><img src='Material/<?php echo $tablero3[5];?>.jpg' height="120px" ></td></tr><tr>
<td><img src='Material/<?php echo $tablero3[6];?>.jpg' height="120px" ></td>
<td><img src='Material/<?php echo $tablero3[7];?>.jpg' height="120px" ></td>
<td><img src='Material/<?php echo $tablero3[8];?>.jpg' height="120px"  ></td></tr></table></div>


</head>
</body>
</html>
