<?php
$cartaRamdom = array();
$cartaRamdomPrimera = mt_rand(1,30);
array_push($cartaRamdom, $cartaRamdomPrimera);
$x = 1;
while ($x < 2){
$SiguienteCartaRamdom = mt_rand(1, 30);
if(in_array($SiguienteCartaRamdom, $cartaRamdom)){
continue;
}else{
array_push($cartaRamdom, $SiguienteCartaRamdom);
echo "<img src='Material/".$cartaRamdom[$x].".jpg' height='60%'><br>";
$x++;
$self = $_SERVER['PHP_SELF'];
header("refresh:3; url=$self");
}
}
?>

<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="estilos2.css">
</head>
<body>

</body>
</html>
