<?php
$Usuario = $_POST['NomUser'];
$nombre = $_POST['Nombre'];
$apellido = $_POST['Apellido'];
$contra = $_POST ['Clave'];
$edad = $_POST['edad'];
$correo_electronico = $_POST['correo'];
$genero = $_POST['genero'];
$db="k10"; $host="localhost"; $pw= ""; $user= "root";
$conector= mysql_connect ($host, $user, $pw) or die ("No se conecto conector.");
mysql_select_db ($db, $conector) or die ("no se conecto select_db");
$registro_completo= "INSERT INTO registro(NomUser, Nombre, Apellido, Clave, edad, correo, genero)
values ('$Usuario', '$nombre', '$apellido', '$contra', '$edad', '$correo_electronico', '$genero') ";
mysql_query ($registro_completo, $conector) or die (mysql_error());
echo "<p><br>Guardado correctamente</p>";
echo "<a href='index.html'>   volver al login   </a>";
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/fuentes.css">
<link rel="stylesheet" href="css/registrofin.css">
<title>¡Ya estas registrado! | K10</title>
</head>
<body>	
</body>
</html>