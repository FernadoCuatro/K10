<?php
session_start ();
error_reporting(0);
$usersesion = $_SESSION['usuario'];
if  ($usersesion == null || $usersesion ='' ){
echo 'usted no puede ingresar, por favor registrese';
die();
}
?>
<!DOCTYPE html>
<html>
<head><meta charset="utf-8">
<title> BaseExpoferia</title>
<link rel="icon" type="icon" href="material/k101.png">
<link rel="stylesheet" href="css/contenido.css">
<link rel="stylesheet" href="css/fuentes.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script></head>
<header>
<nav class="menu">
<div class="enlaces" id="enlaces">
<a href=""><i class=""></i>pantalla 1</a>
<a href=""><i class=""></i>pantalla 2</a></div>
<div class="logo">
<a href=""><img src="material/K10C2.png" alt="k10"></div></a>
<div class="enlaces" id="enlaces">
<a href=""><i class=""></i>pantalla 3</a>
<a href="xsession.php"><i class=""></i>cerrar sesión</a></div></nav>

</header><body>
>
<div class="Papel">
<article>
<h2>¡Hola <?php echo $_SESSION['usuario'] ?>!</h2>
<hr>
<!-- Aqui escriban todo lo de la pagina web, todo el contenido -->
Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat similique corporis optio id voluptate expedita eos neque, omnis sint rerum iusto, modi, ad fuga fugiat nihil eaque accusamus ea praesentium?
<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Veritatis odio soluta expedita natus similique ducimus dolorem ex accusantium, officiis earum cupiditate debitis assumenda minus, eveniet molestiae. Natus libero inventore dolores!</p>
 Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat similique corporis optio id voluptate expedita eos neque,
omnis sint rerum iusto, modi, ad fuga fugiat nihil eaque accusamus ea praesentium?
<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Veritatis odio soluta expedita natus similique ducimus dolorem
    ex accusantium, officiis earum cupiditate debitis assumenda minus, eveniet molestiae. Natus libero inventore dolores!</p>
 Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat similique corporis optio id voluptate expedita eos neque,
omnis sint rerum iusto, modi, ad fuga fugiat nihil eaque accusamus ea praesentium?
<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Veritatis odio soluta expedita natus similique ducimus dolorem
    ex accusantium, officiis earum cupiditate debitis assumenda minus, eveniet molestiae. Natus libero inventore dolores!</p>
 Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat similique corporis optio id voluptate expedita eos neque,
omnis sint rerum iusto, modi, ad fuga fugiat nihil eaque accusamus ea praesentium?
<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Veritatis odio soluta expedita natus similique ducimus dolorem
    ex accusantium, officiis earum cupiditate debitis assumenda minus, eveniet molestiae. Natus libero inventore dolores!</p>
 Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat similique corporis optio id voluptate expedita eos neque,
omnis sint rerum iusto, modi, ad fuga fugiat nihil eaque accusamus ea praesentium?
<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Veritatis odio soluta expedita natus similique ducimus dolorem ex accusantium, officiis earum cupiditate debitis assumenda minus, eveniet molestiae. Natus libero inventore dolores!</p>
 Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat similique corporis optio id voluptate expedita eos neque,
omnis sint rerum iusto, modi, ad fuga fugiat nihil eaque accusamus ea praesentium?
<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Veritatis odio soluta expedita natus similique ducimus dolorem ex accusantium, officiis earum cupiditate debitis assumenda minus, eveniet molestiae. Natus libero inventore dolores!</p>
 Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat similique corporis optio id voluptate expedita eos neque,
omnis sint rerum iusto, modi, ad fuga fugiat nihil eaque accusamus ea praesentium?
<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Veritatis odio soluta expedita natus similique ducimus dolorem ex accusantium, officiis earum cupiditate debitis assumenda minus, eveniet molestiae. Natus libero inventore dolores!</p>
 Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat similique corporis optio id voluptate expedita eos neque,
omnis sint rerum iusto, modi, ad fuga fugiat nihil eaque accusamus ea praesentium?
<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Veritatis odio soluta expedita natus similique ducimus dolorem
    ex accusantium, officiis earum cupiditate debitis assumenda minus, eveniet molestiae. Natus libero inventore dolores!</p>
Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat similique corporis optio id voluptate expedita eos neque,
omnis sint rerum iusto, modi, ad fuga fugiat nihil eaque accusamus ea praesentium?
<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Veritatis odio soluta expedita natus similique ducimus dolorem
    ex accusantium, officiis earum cupiditate debitis assumenda minus, eveniet molestiae. Natus libero inventore dolores!</p>
Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat similique corporis optio id voluptate expedita eos neque,
omnis sint rerum iusto, modi, ad fuga fugiat nihil eaque accusamus ea praesentium?
<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Veritatis odio soluta expedita natus similique ducimus dolorem ex accusantium, officiis earum cupiditate debitis assumenda minus, eveniet molestiae. Natus libero inventore dolores!</p>
 Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat similique corporis optio id voluptate expedita eos neque,
omnis sint rerum iusto, modi, ad fuga fugiat nihil eaque accusamus ea praesentium?
<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Veritatis odio soluta expedita natus similique ducimus dolorem
    ex accusantium, officiis earum cupiditate debitis assumenda minus, eveniet molestiae. Natus libero inventore dolores!</p>
Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat similique corporis optio id voluptate expedita eos neque,
omnis sint rerum iusto, modi, ad fuga fugiat nihil eaque accusamus ea praesentium?
omnis sint rerum iusto, modi, ad fuga fugiat nihil eaque accusamus ea praesentium?
<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Veritatis odio soluta expedita natus similique ducimus dolorem
    ex accusantium, officiis earum cupiditate debitis assumenda minus, eveniet molestiae. Natus libero inventore dolores!</p>
</article>
</div>  
<footer>
<section id="acerca de"><h1><img src="material/k105.png"  width="201px" alt="k10"></h1>
<section id class="Final">
Copyright © Corporacion
</id></footer>
</body>
</html>