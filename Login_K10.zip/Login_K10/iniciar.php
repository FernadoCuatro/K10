<?php
session_start ();

$usuario = $_POST ['correo'];
$clave = $_POST ['contra'];
$_SESSION ['usuario'] = $usuario;

$hots = "localhost";
$user = "root";
$pw = "";
$db = "k10";

$conex = mysqli_connect ($hots, $user, $pw, $db);
$cuestion = "SELECT * FROM registro WHERE correo='$usuario' and Clave='$clave' ";
$cuestionqu = mysqli_query ($conex, $cuestion);
$filas = mysqli_num_rows ($cuestionqu);
if ($filas>0){
header ("location:bienvenidos.php");
}
else {
echo "error en el usuario, por favor registrese. ";
}
mysqli_free_result ($cuestionqu);
mysqli_close ($conex);

?>