CREATE DATABASE k10;
use k10;
CREATE TABLE `registro` (
`NomUser` varchar(15) PRIMARY KEY NOT NULL,
`Nombre` varchar(15) NOT NULL,
`Apellido` varchar(15) NOT NULL,
`Clave` varchar(10)  NOT NULL,
`edad` int(11) NOT NULL,
`correo` varchar(45) NOT NULL,
`genero` varchar(9) NOT NULL
);
